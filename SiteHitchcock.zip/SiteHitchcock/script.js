document.querySelectorAll('.imagem img').forEach(img => {
    img.addEventListener('click', function() {
        const sinopse = this.getAttribute('data-sinopse'); // Altere para getAttribute
        document.getElementById('sinopseTitulo').textContent = this.alt;
        document.getElementById('sinopseTexto').textContent = sinopse;
        document.getElementById('sinopseOverlay').style.display = 'flex';
    });
});

function fecharSinopse() {
    document.getElementById('sinopseOverlay').style.display = 'none';
}
